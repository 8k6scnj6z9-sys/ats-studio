// Pages that ask for a password: if Wall Guard finds signs of imitation (fake bank, lookalike name, IP address),
// show a warning bar before the user types anything. The page itself is never read or sent anywhere.
(() => {
  let done = false;
  function warn(v) {
    const bar = document.createElement("div");
    const root = bar.attachShadow({ mode: "closed" });
    const box = document.createElement("div");
    box.setAttribute("role", "alert");
    box.style.cssText = "position:fixed;top:0;left:0;right:0;z-index:2147483647;background:#7a1f12;color:#fff;font:14px/1.45 -apple-system,Segoe UI,sans-serif;padding:12px 48px 12px 16px;box-shadow:0 2px 8px rgba(0,0,0,.3)";
    const title = document.createElement("b");
    title.textContent = "Wall Guard: cuidado antes de escreveres a password. ";
    const why = document.createElement("span");
    why.textContent = (v.reasons || []).join(" · ");
    const close = document.createElement("button");
    close.textContent = "×";
    close.setAttribute("aria-label", "Fechar aviso");
    close.style.cssText = "position:absolute;top:6px;right:10px;background:none;border:0;color:#fff;font-size:22px;cursor:pointer";
    close.onclick = () => bar.remove();
    box.append(title, why, close);
    root.append(box);
    document.documentElement.append(bar);
  }
  function scan() {
    if (done || !document.querySelector('input[type="password"]')) return;
    done = true;
    chrome.runtime.sendMessage({ type: "check", url: location.href }, (v) => {
      if (chrome.runtime.lastError) return;
      if (v && v.risk !== "sem sinais") warn(v);
    });
  }
  scan();
  // Login forms are often added after load (single-page apps).
  const obs = new MutationObserver(scan);
  obs.observe(document.documentElement, { childList: true, subtree: true });
  setTimeout(() => obs.disconnect(), 30000);
})();
