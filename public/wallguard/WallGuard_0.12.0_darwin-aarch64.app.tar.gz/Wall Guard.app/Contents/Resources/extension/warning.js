const q = new URLSearchParams(location.search);
const url = q.get("u") || "";
document.getElementById("url").textContent = url;
document.getElementById("why").textContent = q.get("r") || "";
document.getElementById("back").onclick = () => (history.length > 2 ? history.go(-2) : window.close());
document.getElementById("go").onclick = () => {
  if (!confirm("Abrir um site conhecido por malware ou phishing? Não escrevas passwords nem descarregues nada dele.")) return;
  // Only http(s) addresses can be opened from here.
  if (!/^https?:\/\//i.test(url)) return;
  chrome.runtime.sendMessage({ type: "allow", url }, () => location.replace(url));
};
