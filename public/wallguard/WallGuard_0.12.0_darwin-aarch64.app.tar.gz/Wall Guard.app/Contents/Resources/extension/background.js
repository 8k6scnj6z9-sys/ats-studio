// Wall Guard extension: asks the Wall Guard app (native messaging) about each page before it opens.
// The app does the checking locally; nothing is sent to any server.
const HOST = "pt.atstudio.wallguard";
const cache = new Map(); // host -> { verdict, at }
const allowed = new Set(); // hosts the user chose to open anyway (this browser session)
const TTL = 10 * 60 * 1000;

function hostOf(url) {
  try { return new URL(url).hostname; } catch { return ""; }
}

async function check(url) {
  const host = hostOf(url);
  const hit = cache.get(host);
  if (hit && Date.now() - hit.at < TTL) return hit.verdict;
  try {
    const verdict = await chrome.runtime.sendNativeMessage(HOST, { url });
    cache.set(host, { verdict, at: Date.now() });
    if (cache.size > 2000) cache.delete(cache.keys().next().value);
    return verdict;
  } catch {
    return null; // app not installed or not reachable: never block browsing because of it
  }
}

chrome.webNavigation.onBeforeNavigate.addListener(async (d) => {
  if (d.frameId !== 0 || !/^https?:/.test(d.url) || allowed.has(hostOf(d.url))) return;
  const v = await check(d.url);
  if (v && v.risk === "perigoso") {
    const page = chrome.runtime.getURL("warning.html") + "?u=" + encodeURIComponent(d.url) + "&r=" + encodeURIComponent(v.reasons.join(" · "));
    chrome.tabs.update(d.tabId, { url: page });
  }
});

chrome.runtime.onMessage.addListener((msg, sender, reply) => {
  if (msg && msg.type === "check" && typeof msg.url === "string") {
    if (allowed.has(hostOf(msg.url))) { reply(null); return; }
    check(msg.url).then(reply);
    return true;
  }
  // Only the extension's own warning page may allow a host.
  if (msg && msg.type === "allow" && sender.url && sender.url.startsWith(chrome.runtime.getURL("warning.html"))) {
    allowed.add(hostOf(msg.url));
    reply(true);
  }
});
